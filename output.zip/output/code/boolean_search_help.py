#Resources referenced:
# Claude AI for implementing class based structure and general questions
# https://www.youtube.com/watch?v=hhjn4HVEdy0&t=35s
# https://www.geeksforgeeks.org/inverted-index/


import argparse
import pickle
import json
from pathlib import Path
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import string
import pandas as pd
from tqdm import tqdm

class BooleanSearcher:
    def __init__(self):
        self.posting_list = {}
        self.lemmatizer = WordNetLemmatizer()
        
        # Download required NLTK data
        for resource in ['punkt', 'stopwords', 'wordnet']:
            try:
                nltk.data.find(f'tokenizers/{resource}' if resource == 'punkt' 
                              else f'corpora/{resource}')
            except LookupError:
                nltk.download(resource)
                
        self.stop_words = set(stopwords.words('english'))
        self.punctuation = set(string.punctuation)
        
    def preprocess_text(self, text):
        if pd.isna(text):
            return []
        tokens = word_tokenize(str(text).lower())
        return [self.lemmatizer.lemmatize(token)
                for token in tokens 
                if token not in self.punctuation 
                and token not in self.stop_words
                and token.isalnum()]
        
    def load_reviews(self, filepath="reviews_segment.pkl"):
        # Load reviews
        with open(filepath, 'rb') as f:
            df = pickle.load(f)
        
        # Create posting list
        for inverted_index in tqdm(df.index, desc="Processing reviews"):
            tokens = self.preprocess_text(df.loc[inverted_index, 'review_text'])
            for token in set(tokens):
                if token not in self.posting_list:
                    self.posting_list[token] = set()
                self.posting_list[token].add(inverted_index)
        
        # Save files
        Path('output').mkdir(exist_ok=True)
        with open('output/posting_list.pkl', 'wb') as f:
            pickle.dump(self.posting_list, f)
        
        json_posting_list = {k: list(v) for k, v in self.posting_list.items()}
        with open('output/posting_list.json', 'w') as f:
            json.dump(json_posting_list, f, indent=2)

    def search_method1(self, aspect1, aspect2, opinion):
        aspect1 = self.lemmatizer.lemmatize(aspect1.lower())
        aspect2 = self.lemmatizer.lemmatize(aspect2.lower())
        opinion_words = [self.lemmatizer.lemmatize(word.lower()) for word in opinion.split()]
        
        result_set = set()
        for word in [aspect1, aspect2] + opinion_words:
            if word in self.posting_list:
                result_set.update(self.posting_list[word])
        return sorted(list(result_set))

    def search_method2(self, aspect1, aspect2, opinion):
        aspect1 = self.lemmatizer.lemmatize(aspect1.lower())
        aspect2 = self.lemmatizer.lemmatize(aspect2.lower())
        opinion_words = [self.lemmatizer.lemmatize(word.lower()) for word in opinion.split()]
        
        if aspect1 not in self.posting_list:
            return []
            
        result_set = self.posting_list[aspect1].copy()
        for word in [aspect2] + opinion_words:
            if word not in self.posting_list:
                return []
            result_set.intersection_update(self.posting_list[word])
        return sorted(list(result_set))

    def search_method3(self, aspect1, aspect2, opinion):
        aspect1 = self.lemmatizer.lemmatize(aspect1.lower())
        aspect2 = self.lemmatizer.lemmatize(aspect2.lower())
        opinion_words = [self.lemmatizer.lemmatize(word.lower()) for word in opinion.split()]
        
        aspect_docs = set()
        for aspect in [aspect1, aspect2]:
            if aspect in self.posting_list:
                aspect_docs.update(self.posting_list[aspect])
        
        if not aspect_docs:
            return []
            
        result_set = aspect_docs
        for word in opinion_words:
            if word not in self.posting_list:
                return []
            result_set.intersection_update(self.posting_list[word])
        return sorted(list(result_set))

    def save_results(self, results, output_file):
        Path('output').mkdir(exist_ok=True)
        with open(f'output/{output_file}', 'wb') as f:
            pickle.dump(results, f)

def main():
    parser = argparse.ArgumentParser(description='Boolean search for aspect pairs and opinions')
    parser.add_argument('--aspect1', required=True, help='First aspect word')
    parser.add_argument('--aspect2', required=True, help='Second aspect word')
    parser.add_argument('--opinion', required=True, help='Opinion word(s)')
    parser.add_argument('--method', required=True, 
                       choices=['method1', 'method2', 'method3'],
                       help='Search method to use')
    
    args = parser.parse_args()
    searcher = BooleanSearcher()
    searcher.load_reviews()
    
    search_methods = {
        'method1': searcher.search_method1,
        'method2': searcher.search_method2,
        'method3': searcher.search_method3
    }
    
    results = search_methods[args.method](args.aspect1, args.aspect2, args.opinion)
    print(f"\nFound {len(results)} matching documents")
    
    output_file = f"{args.aspect1}_{args.aspect2}_{args.opinion.replace(' ', '_')}_{args.method}.pkl"
    searcher.save_results(results, output_file)

if __name__ == "__main__":
    main()